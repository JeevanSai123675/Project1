StudentCoursesManagement - Java Console Project

How to Run:
1. Open any Java IDE (e.g., Eclipse, IntelliJ, or VS Code)
2. Import the Java files from the src/StudentCourseManagement folder
3. Ensure MySQL server is running and database 'schooldb1' is created
4. Run Main.java file to interact with the system

Modules Included:
- Add/View Courses
- Add/View Students
- Enroll Student to Course
- View Enrollments

Report: See report/Project_Report.docx
